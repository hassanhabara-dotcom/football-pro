const $ = (s) => document.querySelector(s);
const today = new Date();
const isoDate = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
$('#matchDate').value = isoDate(today);

const demoMatches = [
 {id:'d1',competition:{name:'الدوري الإنجليزي',code:'PL'},utcDate:new Date().toISOString(),status:'IN_PLAY',homeTeam:{name:'مانشستر سيتي',shortName:'مانشستر سيتي'},awayTeam:{name:'ليفربول',shortName:'ليفربول'},score:{fullTime:{home:1,away:1}},minute:64},
 {id:'d2',competition:{name:'الدوري الإسباني',code:'PD'},utcDate:new Date(Date.now()+3600000).toISOString(),status:'SCHEDULED',homeTeam:{name:'ريال مدريد',shortName:'ريال مدريد'},awayTeam:{name:'برشلونة',shortName:'برشلونة'},score:{fullTime:{home:null,away:null}}},
 {id:'d3',competition:{name:'الدوري السعودي',code:'SAU'},utcDate:new Date(Date.now()+7200000).toISOString(),status:'SCHEDULED',homeTeam:{name:'الهلال',shortName:'الهلال'},awayTeam:{name:'الاتحاد',shortName:'الاتحاد'},score:{fullTime:{home:null,away:null}}},
 {id:'d4',competition:{name:'الدوري الإيطالي',code:'SA'},utcDate:new Date(Date.now()-86400000).toISOString(),status:'FINISHED',homeTeam:{name:'إنتر',shortName:'إنتر'},awayTeam:{name:'ميلان',shortName:'ميلان'},score:{fullTime:{home:2,away:0}}},
 {id:'d5',competition:{name:'دوري أبطال أوروبا',code:'CL'},utcDate:new Date(Date.now()+10800000).toISOString(),status:'SCHEDULED',homeTeam:{name:'بايرن ميونخ',shortName:'بايرن'},awayTeam:{name:'باريس سان جيرمان',shortName:'باريس'},score:{fullTime:{home:null,away:null}}}
];
let matches = [];
let news = [];
let isDemo = false;
const savedKey = 'football-pro-predictions-v1';

function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function timeLabel(m){
 if(m.status==='IN_PLAY'||m.status==='LIVE') return `<span class="status">● مباشر ${m.minute?m.minute+"'":''}</span>`;
 if(m.status==='PAUSED') return '<span class="status">استراحة</span>';
 if(m.status==='FINISHED') return '<span>انتهت</span>';
 return new Date(m.utcDate).toLocaleTimeString('ar-SA',{hour:'2-digit',minute:'2-digit'});
}
function scoreLabel(m){
 const h=m.score?.fullTime?.home, a=m.score?.fullTime?.away;
 if(h===null||h===undefined||a===null||a===undefined) return '<span class="score pending">لم تبدأ</span>';
 return `<span class="score">${h} - ${a}</span>`;
}
function matchCard(m){
 const home=m.homeTeam?.shortName||m.homeTeam?.name||'الفريق الأول';
 const away=m.awayTeam?.shortName||m.awayTeam?.name||'الفريق الثاني';
 return `<article class="match-card">
  <div class="match-meta"><span>${escapeHtml(m.competition?.name||'مباراة')}</span><span>${timeLabel(m)}</span></div>
  <div class="teams">
   <div class="team"><span class="crest">⚽</span><span class="team-name">${escapeHtml(home)}</span></div>
   ${scoreLabel(m)}
   <div class="team away"><span class="team-name">${escapeHtml(away)}</span><span class="crest">⚽</span></div>
  </div>
  <div class="match-bottom"><span class="league">${new Date(m.utcDate).toLocaleDateString('ar-SA',{day:'numeric',month:'short'})}</span><button class="mini-btn highlight-search" data-home="${escapeHtml(home)}" data-away="${escapeHtml(away)}">الملخصات ↗</button></div>
 </article>`;
}
function renderMatches(){
 const filter=$('#leagueFilter').value;
 const filtered=matches.filter(m=>filter==='all'||m.competition?.code===filter);
 $('#matchCount').textContent=`${filtered.length} مباراة`;
 $('#matches').innerHTML=filtered.length?filtered.map(matchCard).join(''):'<div class="empty">لا توجد مباريات في هذا اليوم. جرّب تاريخاً آخر.</div>';
 $('#matches').querySelectorAll('.highlight-search').forEach(b=>b.addEventListener('click',()=>openHighlights(b.dataset.home,b.dataset.away)));
 renderPredictionOptions();
}
function renderNews(){
 $('#newsList').innerHTML=news.length?news.map(n=>`<article class="news-card"><div class="news-date">${escapeHtml(n.date||'آخر الأخبار')}</div><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.description||'تابع تفاصيل الخبر من المصدر الأصلي.')}</p><a href="${escapeHtml(n.link)}" target="_blank" rel="noreferrer">اقرأ الخبر من المصدر ↗</a></article>`).join(''):'<div class="empty">لا تتوفر أخبار حالياً.</div>';
}
function renderHighlights(){
 const upcoming=[...matches].sort((a,b)=>new Date(b.utcDate)-new Date(a.utcDate));
 $('#highlightsList').innerHTML=upcoming.slice(0,12).map(m=>{
 const h=m.homeTeam?.shortName||m.homeTeam?.name, a=m.awayTeam?.shortName||m.awayTeam?.name;
 return `<div class="highlight-item"><strong>${escapeHtml(h)} — ${escapeHtml(a)}</strong><a target="_blank" rel="noreferrer" href="https://www.youtube.com/results?search_query=${encodeURIComponent(h+' '+a+' highlights official')}">ابحث عن الملخص ↗</a></div>`;
 }).join('')||'<div class="empty">لا توجد مباريات لعرضها.</div>';
}
function renderPredictionOptions(){
 const list=matches.filter(m=>m.status==='SCHEDULED'||m.status==='TIMED');
 const sel=$('#predictionMatch'); const old=sel.value;
 sel.innerHTML=list.length?list.map(m=>`<option value="${escapeHtml(m.id)}">${escapeHtml(m.homeTeam?.name)} × ${escapeHtml(m.awayTeam?.name)} — ${new Date(m.utcDate).toLocaleDateString('ar-SA')}</option>`).join(''):'<option value="">لا توجد مباريات قادمة في التاريخ المختار</option>';
 if(list.some(m=>String(m.id)===old))sel.value=old;
 updatePredictionTeams();
}
function updatePredictionTeams(){
 const m=matches.find(x=>String(x.id)===$('#predictionMatch').value);
 $('#homePredictionName').textContent=m?.homeTeam?.shortName||m?.homeTeam?.name||'الفريق الأول';
 $('#awayPredictionName').textContent=m?.awayTeam?.shortName||m?.awayTeam?.name||'الفريق الثاني';
}
function readSaved(){try{return JSON.parse(localStorage.getItem(savedKey)||'[]')}catch{return []}}
function renderSaved(){
 const data=readSaved();
 $('#savedPredictions').innerHTML=data.length?data.map(p=>`<div class="saved-row"><span>${escapeHtml(p.match)}</span><b>${p.home} - ${p.away}</b></div>`).join(''):'<p class="muted">لم تحفظ أي توقع بعد.</p>';
}
function savePrediction(){
 const m=matches.find(x=>String(x.id)===$('#predictionMatch').value);
 if(!m){$('#predictionResult').textContent='لا توجد مباراة قادمة لهذا التاريخ.';return;}
 const h=Number($('#homeGoals').value),a=Number($('#awayGoals').value);
 if(!Number.isInteger(h)||!Number.isInteger(a)||h<0||a<0||h>20||a>20){$('#predictionResult').textContent='أدخل أهدافاً من 0 إلى 20.';return;}
 const item={id:String(m.id),match:`${m.homeTeam.name} × ${m.awayTeam.name}`,home:h,away:a};
 const all=readSaved().filter(p=>p.id!==item.id);all.unshift(item);localStorage.setItem(savedKey,JSON.stringify(all.slice(0,20)));
 $('#predictionResult').textContent=`تم حفظ توقعك: ${h} - ${a}. بالتوفيق!`;
 renderSaved();
}
function openHighlights(home,away){
 switchTab('highlights');
 const q=home+' '+away+' highlights official';
 window.open('https://www.youtube.com/results?search_query='+encodeURIComponent(q),'_blank','noopener');
}
function switchTab(tab){
 document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 ['scores','news','highlights','predict'].forEach(t=>$('#'+t+'Panel').classList.toggle('hidden',t!==tab));
 $('#sectionTitle').textContent=({scores:'المباريات والنتائج',news:'آخر الأخبار',highlights:'ملخصات المباريات',predict:'توقع نتيجة المباراة'})[tab];
 if(tab==='highlights')renderHighlights();
 if(tab==='predict')renderSaved();
}
async function loadData(){
 $('#matches').innerHTML='<div class="loading">جارٍ تحميل المباريات…</div>';
 const date=$('#matchDate').value||isoDate(today);
 try{
  const res=await fetch(`/api/matches?date=${encodeURIComponent(date)}`);
  if(!res.ok)throw new Error('API unavailable');
  const data=await res.json();
  matches=data.demo?demoMatches:(Array.isArray(data.matches)?data.matches:[]);
  isDemo=!!data.demo;
  $('#connection').textContent=isDemo?'● وضع تجريبي':'● بيانات متصلة';
  $('#connection').classList.toggle('live',!isDemo);
  $('#dataNote').textContent=isDemo?'هذه بيانات توضيحية وليست نتائج مباشرة. فعّل مفتاح مزوّد البيانات في الخادم لعرض النتائج الحقيقية.':'المباريات من مزوّد البيانات المتصل. قد تختلف التغطية حسب البطولة وخطة الاشتراك.';
 }catch(e){
  matches=demoMatches;isDemo=true;
  $('#connection').textContent='● وضع تجريبي';$('#connection').classList.remove('live');
  $('#dataNote').textContent='تعذّر الاتصال بالخادم؛ المعروض بيانات تجريبية وليست نتائج حقيقية.';
 }
 renderMatches();renderHighlights();
}
async function loadNews(){
 try{
  const res=await fetch('/api/news');if(!res.ok)throw new Error();
  const data=await res.json();news=data.items||[];
 }catch{news=[];}
 renderNews();
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
$('#leagueFilter').addEventListener('change',renderMatches);
$('#matchDate').addEventListener('change',loadData);
$('#refreshBtn').addEventListener('click',()=>{loadData();loadNews();});
$('#predictionMatch').addEventListener('change',updatePredictionTeams);
$('#savePrediction').addEventListener('click',savePrediction);
$('#settingsBtn').addEventListener('click',()=>$('#settingsDialog').showModal());
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
loadData();loadNews();renderSaved();
