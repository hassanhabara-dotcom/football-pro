const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const TOKEN = process.env.FOOTBALL_DATA_TOKEN;
const PUBLIC = path.join(__dirname, 'public');
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml'};

function send(res, status, body, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}
function dateOnly(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s||'') ? s : new Date().toISOString().slice(0,10); }

async function matches(date) {
  if (!TOKEN) return {demo:true,matches:[]};
  const url = `https://api.football-data.org/v4/matches?dateFrom=${date}&dateTo=${date}&competitions=PL,PD,BL1,SA,FL1,CL`;
  const r = await fetch(url, {headers:{'X-Auth-Token':TOKEN}});
  if (!r.ok) throw new Error(`Football data provider returned ${r.status}`);
  const data = await r.json();
  return {demo:false,matches:data.matches||[]};
}
function decodeXml(s='') {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]+>/g,' ').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\s+/g,' ').trim();
}
async function news() {
  const r=await fetch('https://feeds.bbci.co.uk/sport/football/rss.xml',{headers:{'User-Agent':'FootballPro/1.0'}});
  if(!r.ok) throw new Error('News feed unavailable');
  const xml=await r.text();
  const items=[...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0,12).map(m=>{
    const x=m[1], get=(tag)=>{const found=x.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`,'i'));return found?decodeXml(found[1]):'';};
    return {title:get('title'),description:get('description'),link:get('link'),date:get('pubDate')};
  }).filter(x=>x.title&&x.link);
  return {items};
}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/health')return send(res,200,{ok:true,providerConfigured:!!TOKEN});
  if(url.pathname==='/api/matches'){
    try{const data=await matches(dateOnly(url.searchParams.get('date')));return send(res,200,data);}
    catch(e){return send(res,502,{error:'تعذر جلب المباريات من المزوّد',detail:e.message});}
  }
  if(url.pathname==='/api/news'){
    try{return send(res,200,await news());}
    catch(e){return send(res,502,{error:'تعذر جلب الأخبار حالياً'});}
  }
  let requested=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
  const file=path.normalize(path.join(PUBLIC,requested));
  if(!file.startsWith(PUBLIC))return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,data)=>{
    if(err)return send(res,404,'Not found','text/plain; charset=utf-8');
    res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream'});
    res.end(data);
  });
});
server.listen(PORT,()=>console.log(`FOOTBALL PRO running at http://localhost:${PORT}`));
